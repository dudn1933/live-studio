import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-trend-data',
  templateUrl: './trend-data.component.html',
  styleUrls: ['./trend-data.component.scss']
})
export class TrendDataComponent implements OnInit {
  @Input() waveData: any;
  @Input() spaceIndex: any;

  constructor() {}

  ngOnInit(): void {
    this.waveData.subscribe((res:any) => {
      // console.log(res.data.trendData)
    })
  }

}
