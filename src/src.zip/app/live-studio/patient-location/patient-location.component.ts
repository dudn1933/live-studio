import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-patient-location',
  templateUrl: './patient-location.component.html',
  styleUrls: ['./patient-location.component.scss']
})
export class PatientLocationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
