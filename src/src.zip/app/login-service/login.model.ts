export interface Login {
    accountID: string;
    password: string;
}